//
//  History.cpp
//  Project 1
//
//  Created by Anica Wang on 1/7/21.
//

#include "History.h"
#include <iostream>

using namespace std;

History::History(int nRows, int nCols)
{
    m_rows = nRows;
    m_cols = nCols;
    
    for (int i = 0; i < m_rows; i++)
    {
        for (int j = 0; j < m_cols; j++)
        {
            m_turns[i][j] = 0;
        }
    }
}

bool History::record(int r, int c)
{
    r--;
    c--;
    
    if (r < 0 || c < 0 || r >= m_rows || c >= m_cols)
    {
        return false;
    }
    m_turns[r][c]++;
    return true;
}

void History::display() const
{
    clearScreen();
    
    for (int i = 0; i < m_rows; i++)
    {
        for (int j = 0; j < m_cols; j++)
        {
            int x = m_turns[i][j];
            char c;
            
            if (x == 0)
            {
                c = '.';
            }
            
            else if (x >= 1 && x <= 26)
            {
                c = 'A' + (x - 1);
            }
            
            else
            {
                c = 'Z';
            }
            
            cout << c;
        }
        cout << endl;
    }
    cout << endl;
    return;
}
